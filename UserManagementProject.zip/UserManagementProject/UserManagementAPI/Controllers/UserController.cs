﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserManagementAPI.Database;
using UserManagementAPI.Model;
using static System.Runtime.InteropServices.JavaScript.JSType;

[Route("api/[controller]")]
[ApiController]
public class UserController : ControllerBase
{
    //varibale/object decration
	private readonly DBOperations dbOperations;

    public UserController()
    {
        //varibale/object intialization... DBOperation .
        dbOperations = new DBOperations();
    }


    //Save new user data to database
    [HttpPost]
    public bool PostUser(User userdata)
    {
		try
		{
            dbOperations.CreateUser(userdata);

            return true;
        }
		catch (Exception ex)
		{
            return false;   
		}
    }

    //Get all user data from database
    [HttpGet]
    public List<UserDetails> GetUser()
    {
        try
        {
            var userDetailList  = dbOperations.GetAllUserDetails();

            return userDetailList;
        }
        catch (Exception ex)
        {
            return null;
        }
    }


    //Get user data by userId from database
    [HttpGet("{userId}")]
    public UserDetails GetUser(int userId)
    {
        try
        {
            var userDetail = dbOperations.GetUserDetailsById(userId);

          
            return userDetail;

        }
        catch (Exception ex)
        {
            return null;
        }
    }

    //Update user data by userId in database
    [HttpDelete("{userId}")]
    public bool DeleteUser(int userId)
    {
        try
        {
            var isDeleted = dbOperations.DeleteUserById(userId);

            return isDeleted;

        }
        catch (Exception ex)
        {
            return false;
        }
    }



    //Update user data by userId in database
    [HttpPut("{userId}")]
    public bool PutUser(User userdata, int userId)
    {
        try
        {
            dbOperations.UpdateUser(userdata, userId);

            return true;
        }
        catch (Exception ex)
        {
            return false;
        }
    }

}
