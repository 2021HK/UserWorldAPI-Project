﻿namespace UserManagementAPI.Model
{
    public class Nationality
    {
        public int NationalityId { get; set; }
        public string Name { get; set; }

    }
}
