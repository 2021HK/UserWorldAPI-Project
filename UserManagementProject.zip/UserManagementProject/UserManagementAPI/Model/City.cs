﻿using System.Collections;

namespace UserManagementAPI.Model
{
    public class City
    {
        public int CityId { get; set; }
        public string Name { get; set; }
    }
}
